// import HomePage from "../pages/homePage";
// import About from "../pages/About";
// import Products from "../pages/Products";
// import ProductsDetails from "../pages/ProductDetails";
// import Carts from "../pages/Carts";
// import Services from "../pages/Services";
// import Contact from "../pages/Contact";
// import Checkout from "../pages/Checkout";

import { version } from "react";

// module.exports = {
//   HomePage,
//   About,
//   Products,
//   ProductsDetails,
//   Carts,
//   Services,
//   Contact,
//   Checkout,
// };

import image1 from "../Assests/s1.jpg";
import image2 from "../Assests/s2.jpg";
import image3 from "../Assests/s3.jpg";
import image4 from "../Assests/s4.jpg";
import offer from "../Assests/solar 3.jpg";
export const TimeCountData = [
  {
    time: 1,
    category: "days",
  },
  {
    time: 3,
    category: "Hours",
  },
  {
    time: 3,
    category: "Minutes",
  },
  ,
  {
    time: 3,
    category: "seconds",
  },
];
export const ProductBannerData = [
  {
    version: " mordern edition",
    details: `Lorem ipsum dolor sit amet consectetur adipisicing elit Lorem
                ipsum dolor sit amet consectetur..`,
    price: "$155",
    image: image1,
  },
  {
    version: " mordern edition",
    details: `Lorem ipsum dolor sit amet consectetur adipisicing elit Lorem
                ipsum dolor sit amet consectetur..`,
    price: "$155",
    image: image2,
  },
  {
    version: " mordern edition",
    details: `Lorem ipsum dolor sit amet consectetur adipisicing elit Lorem
                ipsum dolor sit amet consectetur..`,
    price: "$155",
    image: image1,
  },
  {
    version: " mordern edition",
    details: `Lorem ipsum dolor sit amet consectetur adipisicing elit Lorem
                ipsum dolor sit amet consectetur..`,
    price: "$155",
    image: image4,
  },
];

export const Offer = [
  {
    image: offer,
    advert: "solar Pannel + lead Inveter + free delivery",
    price: "$200",
    Details:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Velit, quis",
  },
  // {
  //   image: offer,
  //   advert: "solar Pannel + lead Inveter + free delivery",
  //   price: "$200",
  //   Details:
  //     "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Velit, quis",
  // },
  // {
  //   image: offer,
  //   advert: "solar Pannel + lead Inveter + free delivery",
  //   price: "$200",
  //   Details:
  //     "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Velit, quis",
  // },
];
