import avatar from "../Assests/avatar.png";
import carts from "../Assests/catrs.jpeg";

export const Avatar = avatar;
export const Cart = carts;
